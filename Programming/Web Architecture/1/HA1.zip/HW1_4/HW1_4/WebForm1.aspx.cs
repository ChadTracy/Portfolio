﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1_4
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            ;

            if (!IsPostBack)
            {
                bookList.Items.Add("Introduction to MIS");
                bookList.Items.Add("Introduction to Marketing");
                bookList.Items.Add("Introduction to Finanace ");


            }
        }

        protected void purchaseBtn_Click(object sender, EventArgs e)
        {
            double number;
            number = double.Parse(quantityTB.Text);

            switch (bookList.SelectedItem.Text)
            {
                case "Introduction to MIS":
                    confirmLabel.Text = "You have selected " + number + " number of Introduction to MIS the price is " + number * bookPrice("Introduction to MIS");
                    break;
                case "Introduction to Marketing":
                    confirmLabel.Text = "You have selected " + number + " number of Introduction to Marketing the price is " + number * bookPrice("Introduction to Marketing");
                    break;
                case "Introduction to Finance":
                    confirmLabel.Text = "You have selected " + number + " number of Introduction to Finance the price is " + number * bookPrice("Introduction to Finance");
                    break;
            }
        }

        public double bookPrice(string book)
        {
            book = bookList.SelectedItem.Text;

            if (book == "Introduction to MIS")
            {
                return 20.00;
            }
            else if (book == "Introduction to Marketing")
            {
                return 30.00;
            }
            else
            {
                return 40.00;
            }
        }
    }
}