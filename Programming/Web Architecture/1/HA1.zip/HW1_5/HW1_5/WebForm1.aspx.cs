﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1_5
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        //acct balances
        public double savingsAccount = 30345.90;
        public double checkingsAccount = 40785.22;
        public double sdtAccount = 5643.23;

        public double wdrawAmount;
        public double selectedAccount;
        public double finalAmount;

        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            if (!IsPostBack)
            {
                acctDropDown.Items.Add("Savings Account");
                acctDropDown.Items.Add("Checkings Account");
                acctDropDown.Items.Add("Student Account");
            }
        }

        protected void withdrawBtn_Click(object sender, EventArgs e)
        {
            wdrawAmount = double.Parse(amtTB.Text);
            
            switch (acctDropDown.SelectedItem.Text)
            {
                case "Savings Account":
                    selectedAccount = savingsAccount;
                    break;
                case "Checkings Account":
                    selectedAccount = checkingsAccount;
                    break;
                case "Student Account":
                    selectedAccount = sdtAccount;
                    break;
            }

            if (wdrawAmount > selectedAccount)
            {
                msgLabel.Text = "Withdrawl amount is greater than the balance which is " + selectedAccount;
            }
            else if (wdrawAmount <= selectedAccount)
            {
                finalAmount = selectedAccount - wdrawAmount;
                msgLabel.Text = "Withdrawl successful. Your new balance is " + finalAmount;
            }
    }

    }
}
