﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HW1_2 
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;
            ;

            if (!IsPostBack)
            {
                bookList.Items.Add("Introduction to MIS");
                bookList.Items.Add("Introduction to Marketing");
                bookList.Items.Add("Introduction to Finanace ");


            }
        }

        protected void purchaseBtn_Click(object sender, EventArgs e)
        {
            int number;
            number = int.Parse(quantityTB.Text);

            switch (bookList.SelectedItem.Text)
            {
                case "Introduction to MIS":
                    confirmLabel.Text = "You have selected "+ number +" number of Introduction to MIS";
                    break;
                case "Introduction to Marketing":
                    confirmLabel.Text = "You have selected "+ number+" number of Introduction to Marketing";
                    break;
                case "Introduction to Finance":
                    confirmLabel.Text = "You have selected " + number + " number of Introduction to Finance";
                    break;
            }
        }
    }
}